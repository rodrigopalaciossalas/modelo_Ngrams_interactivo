#ifndef INPUTOUTPUT_HPP
#define INPUTOUTPUT_HPP

class InputOutput {
public:
    static void mostrarLista(char** lista, int cantidad);
};

#endif
