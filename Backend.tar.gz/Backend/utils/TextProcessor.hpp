#ifndef TEXTPROCESSOR_HPP
#define TEXTPROCESSOR_HPP

class TextProcessor {
public:
    static char* limpiarEspacios(const char* texto);
};

#endif
